<?php

namespace Velhron\DadataBundle\Model\Response\Geolocate;

use Velhron\DadataBundle\Model\Response\Suggest\SuggestResponse;

abstract class GeolocateResponse extends SuggestResponse
{
}
