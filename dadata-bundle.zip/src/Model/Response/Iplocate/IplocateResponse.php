<?php

namespace Velhron\DadataBundle\Model\Response\Iplocate;

use Velhron\DadataBundle\Model\Response\Suggest\SuggestResponse;

abstract class IplocateResponse extends SuggestResponse
{
}
