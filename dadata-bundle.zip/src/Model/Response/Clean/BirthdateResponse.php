<?php

namespace Velhron\DadataBundle\Model\Response\Clean;

class BirthdateResponse extends CleanResponse
{
    /** Стандартизованная дата */
    public string $birthdate;
}
