<?php

namespace Velhron\DadataBundle\Model\Response\Clean;

class PassportResponse extends CleanResponse
{
    /** Серия */
    public string $series;

    /** Номер */
    public string $number;
}
