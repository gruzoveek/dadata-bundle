<?php

namespace Velhron\DadataBundle\Model\Response\Clean;

class VehicleResponse extends CleanResponse
{
    /** Марка */
    public string $brand;

    /** Модель */
    public string $model;
}
