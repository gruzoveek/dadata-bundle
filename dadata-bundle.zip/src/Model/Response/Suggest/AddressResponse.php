<?php

namespace Velhron\DadataBundle\Model\Response\Suggest;

use Velhron\DadataBundle\Traits\Address;

class AddressResponse extends SuggestResponse
{
    use Address;
}
