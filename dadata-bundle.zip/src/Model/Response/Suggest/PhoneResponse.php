<?php

namespace Velhron\DadataBundle\Model\Response\Suggest;

use Velhron\DadataBundle\Traits\Phone;

class PhoneResponse extends SuggestResponse
{
    use Phone;
}
