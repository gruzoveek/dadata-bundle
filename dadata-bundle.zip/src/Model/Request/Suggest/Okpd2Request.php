<?php

namespace Velhron\DadataBundle\Model\Request\Suggest;

class Okpd2Request extends SuggestRequest
{
    /** Фильтрация */
    public array $filters;
}
