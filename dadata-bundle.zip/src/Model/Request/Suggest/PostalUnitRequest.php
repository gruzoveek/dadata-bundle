<?php

namespace Velhron\DadataBundle\Model\Request\Suggest;

class PostalUnitRequest extends SuggestRequest
{
    /** Фильтрация */
    protected array $filters;
}
