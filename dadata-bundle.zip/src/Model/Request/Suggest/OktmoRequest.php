<?php

namespace Velhron\DadataBundle\Model\Request\Suggest;

class OktmoRequest extends SuggestRequest
{
}
