<?php

namespace Velhron\DadataBundle\Model\Request\Suggest;

class CountryRequest extends SuggestRequest
{
}
