<?php

namespace Velhron\DadataBundle\Model\Request\Suggest;

class Okved2Request extends SuggestRequest
{
    /** Фильтрация */
    public array $filters;
}
