<?php

namespace Velhron\DadataBundle\Model\Request\Suggest;

class FnsUnitRequest extends SuggestRequest
{
    /** Фильтрация */
    public array $filters;
}
