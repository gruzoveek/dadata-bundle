<?php

namespace Velhron\DadataBundle\Model\Request\Suggest;

class MetroRequest extends SuggestRequest
{
    /** Фильтрация */
    public array $filters;
}
