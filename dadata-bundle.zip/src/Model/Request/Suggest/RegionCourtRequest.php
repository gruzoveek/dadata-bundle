<?php

namespace Velhron\DadataBundle\Model\Request\Suggest;

class RegionCourtRequest extends SuggestRequest
{
    /** Фильтрация */
    protected array $filters;
}
