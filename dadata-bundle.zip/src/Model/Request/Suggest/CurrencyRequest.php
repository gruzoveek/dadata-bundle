<?php

namespace Velhron\DadataBundle\Model\Request\Suggest;

class CurrencyRequest extends SuggestRequest
{
}
