<?php

namespace Velhron\DadataBundle\Model\Request\Suggest;

class CarBrandRequest extends SuggestRequest
{
}
