<?php

namespace Velhron\DadataBundle\Model\Request\Geolocate;

class PostalUnitRequest extends GeolocateRequest
{
}
