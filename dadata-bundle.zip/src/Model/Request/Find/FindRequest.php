<?php

namespace Velhron\DadataBundle\Model\Request\Find;

use Velhron\DadataBundle\Model\Request\Suggest\SuggestRequest;

abstract class FindRequest extends SuggestRequest
{
}
