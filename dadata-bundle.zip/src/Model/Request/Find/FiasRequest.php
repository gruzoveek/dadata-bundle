<?php

namespace Velhron\DadataBundle\Model\Request\Find;

class FiasRequest extends FindRequest
{
}
