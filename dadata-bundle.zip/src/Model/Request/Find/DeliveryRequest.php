<?php

namespace Velhron\DadataBundle\Model\Request\Find;

class DeliveryRequest extends FindRequest
{
}
