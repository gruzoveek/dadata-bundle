<?php

namespace Velhron\DadataBundle\Model\Request\Find;

class RegionCourtRequest extends FindRequest
{
    /** Фильтрация */
    protected array $filters;
}
