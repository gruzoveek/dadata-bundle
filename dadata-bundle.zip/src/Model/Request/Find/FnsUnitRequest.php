<?php

namespace Velhron\DadataBundle\Model\Request\Find;

class FnsUnitRequest extends FindRequest
{
    /** Фильтрация */
    public array $filters;
}
