<?php

namespace Velhron\DadataBundle\Model\Request\Find;

class BankRequest extends FindRequest
{
}
