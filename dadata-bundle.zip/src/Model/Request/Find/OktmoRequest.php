<?php

namespace Velhron\DadataBundle\Model\Request\Find;

class OktmoRequest extends FindRequest
{
}
