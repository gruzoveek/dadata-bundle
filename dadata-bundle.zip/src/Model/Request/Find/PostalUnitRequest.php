<?php

namespace Velhron\DadataBundle\Model\Request\Find;

class PostalUnitRequest extends FindRequest
{
}
