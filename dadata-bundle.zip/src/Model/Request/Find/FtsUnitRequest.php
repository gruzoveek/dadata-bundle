<?php

namespace Velhron\DadataBundle\Model\Request\Find;

class FtsUnitRequest extends FindRequest
{
}
