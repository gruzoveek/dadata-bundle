<?php

namespace Velhron\DadataBundle\Model\Request\Clean;

class NameRequest extends CleanRequest
{
}
