<?php

namespace Velhron\DadataBundle\Model\Request\Clean;

class PassportRequest extends CleanRequest
{
}
