<?php

namespace Velhron\DadataBundle\Model\Request\Clean;

class EmailRequest extends CleanRequest
{
}
