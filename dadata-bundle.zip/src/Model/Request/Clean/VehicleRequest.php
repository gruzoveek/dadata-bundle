<?php

namespace Velhron\DadataBundle\Model\Request\Clean;

class VehicleRequest extends CleanRequest
{
}
