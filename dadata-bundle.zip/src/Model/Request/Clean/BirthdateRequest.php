<?php

namespace Velhron\DadataBundle\Model\Request\Clean;

class BirthdateRequest extends CleanRequest
{
}
