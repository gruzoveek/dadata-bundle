<?php

namespace Velhron\DadataBundle\Model\Request\General;

class BalanceRequest extends GeneralRequest
{
}
