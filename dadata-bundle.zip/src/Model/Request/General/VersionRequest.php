<?php

namespace Velhron\DadataBundle\Model\Request\General;

class VersionRequest extends GeneralRequest
{
}
