<?php

namespace Velhron\DadataBundle\Exception;

use Exception;

class InvalidConfigException extends Exception
{
}
