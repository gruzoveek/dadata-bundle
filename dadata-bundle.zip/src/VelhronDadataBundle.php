<?php

namespace Velhron\DadataBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class VelhronDadataBundle extends Bundle
{
}
